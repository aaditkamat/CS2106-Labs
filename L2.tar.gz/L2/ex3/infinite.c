#include <stdio.h>

/* Infinite loop! Enough said */

int main()
{
    while(1);

    return 0;
}
